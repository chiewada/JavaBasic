package practice01;
/*
 * PTra01_07.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_07 {
	public static void main(String[] args) {

		// 基本型8種類の変数を宣言します
		boolean bo;
		byte by;
		short s;
		char c;
		int i;
		long l;
		float f;
		double d;

		// ★ それぞれの型変数に、値を代入してください
		// ※ 値は、好きな数字を入力してください









		// ★ それぞれの変数の中身を出力してください









	}
}
