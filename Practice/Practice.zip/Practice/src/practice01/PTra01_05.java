package practice01;
/*
 * PTra01_05.java
 *   作成	LIKEIT	2017
 *------------------------------------------------------------
 * Copyright(c) Rhizome Inc. All Rights Reserved.
 */

public class PTra01_05 {
	public static void main(String[] args) {

		// ★ char型の変数 c を宣言してください


		// ★ 変数 c に文字「R」を代入してください


		// ★ 変数 c の中身を出力してください


	}
}
